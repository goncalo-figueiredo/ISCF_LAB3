"""
External-Facing REST API  –  Orchestrates MS1 (Java) + MS2 (Python) via gRPC
Run locally: uvicorn main:app --reload --port 8000
"""

import os
import logging
from typing import List, Optional

import grpc
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# gRPC stubs (generated from inventory.proto)
import inventory_pb2 as pb2
import inventory_pb2_grpc as pb2_grpc

logging.basicConfig(level=logging.INFO, format="%(asctime)s [REST-API] %(message)s")
log = logging.getLogger(__name__)

# ── gRPC endpoints from env (Docker Compose will inject these) ────────────────
MS1_HOST = os.getenv("MS1_HOST", "localhost")
MS1_PORT = os.getenv("MS1_PORT", "50051")
MS2_HOST = os.getenv("MS2_HOST", "localhost")
MS2_PORT = os.getenv("MS2_PORT", "50052")

app = FastAPI(
    title="ISCF Lab3 – Inventory Recommendation API",
    description="Orchestrates Demand Forecasting (MS1/Java) and Inventory Optimisation (MS2/Python) via gRPC.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Pydantic models ───────────────────────────────────────────────────────────

class ForecastRequest(BaseModel):
    item_id: str
    historical_demand: List[float] = Field(..., min_items=1)
    forecast_horizon: int = Field(default=1, ge=1)
    warehouse_id: str = ""
    current_stock: int = Field(..., ge=0)
    reorder_level: int = Field(..., ge=0)
    safety_stock: Optional[int] = 0
    supplier_lead_time: Optional[int] = 0


class ForecastResponse(BaseModel):
    item_id: str
    predicted_demand: float
    forecast_confidence: float
    forecast_horizon: int
    reorder_quantity: int
    inventory_adjustment_action: str
    explanation_message: str


class BatchForecastRequest(BaseModel):
    items: List[ForecastRequest]


class BatchForecastResponse(BaseModel):
    recommendations: List[ForecastResponse]


# ── Helpers ───────────────────────────────────────────────────────────────────

def _ms1_channel():
    return grpc.insecure_channel(f"{MS1_HOST}:{MS1_PORT}")


def _ms2_channel():
    return grpc.insecure_channel(f"{MS2_HOST}:{MS2_PORT}")


def _grpc_error_to_http(e: grpc.RpcError):
    code_map = {
        grpc.StatusCode.INVALID_ARGUMENT: 422,
        grpc.StatusCode.NOT_FOUND: 404,
        grpc.StatusCode.UNAVAILABLE: 503,
    }
    status = code_map.get(e.code(), 500)
    raise HTTPException(status_code=status, detail=f"gRPC error [{e.code()}]: {e.details()}")


def _process_one(item: ForecastRequest) -> ForecastResponse:
    """Call MS1 → MS2 and return the combined result."""

    # 1. Call MS1 (Demand Forecast)
    try:
        with _ms1_channel() as ch:
            ms1_stub = pb2_grpc.DemandForecastServiceStub(ch)
            ms1_req = pb2.DemandForecastRequest(
                item_id=item.item_id,
                historical_demand=item.historical_demand,
                forecast_horizon=item.forecast_horizon,
                warehouse_id=item.warehouse_id,
            )
            ms1_resp = ms1_stub.ForecastDemand(ms1_req, timeout=10)
            log.info("MS1 → item=%s predicted=%.2f confidence=%.2f",
                     ms1_resp.item_id, ms1_resp.predicted_demand, ms1_resp.forecast_confidence)
    except grpc.RpcError as e:
        _grpc_error_to_http(e)

    # 2. Call MS2 (Inventory Optimisation) using MS1 predicted demand
    try:
        with _ms2_channel() as ch:
            ms2_stub = pb2_grpc.InventoryOptimizationServiceStub(ch)
            ms2_req = pb2.InventoryOptimizationRequest(
                item_id=item.item_id,
                current_stock=item.current_stock,
                predicted_demand=ms1_resp.predicted_demand,
                reorder_level=item.reorder_level,
                safety_stock=item.safety_stock or 0,
                supplier_lead_time=item.supplier_lead_time or 0,
            )
            ms2_resp = ms2_stub.OptimizeInventory(ms2_req, timeout=10)
            log.info("MS2 → item=%s action=%s qty=%d",
                     ms2_resp.item_id, ms2_resp.inventory_adjustment_action, ms2_resp.reorder_quantity)
    except grpc.RpcError as e:
        _grpc_error_to_http(e)

    action_name = "SCALE_UP" if ms2_resp.inventory_adjustment_action == pb2.InventoryAdjustmentAction.SCALE_UP else "SCALE_DOWN"

    return ForecastResponse(
        item_id=ms1_resp.item_id,
        predicted_demand=ms1_resp.predicted_demand,
        forecast_confidence=ms1_resp.forecast_confidence,
        forecast_horizon=ms1_resp.forecast_horizon,
        reorder_quantity=ms2_resp.reorder_quantity,
        inventory_adjustment_action=action_name,
        explanation_message=ms2_resp.explanation_message,
    )


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/api/recommend", response_model=ForecastResponse, tags=["Inventory"])
def recommend(request: ForecastRequest):
    """
    Full pipeline for a single item:
    1. Send historical demand to MS1 (Java) → get predicted demand.
    2. Send predicted demand + stock info to MS2 (Python) → get reorder recommendation.
    """
    return _process_one(request)


@app.post("/api/recommend/batch", response_model=BatchForecastResponse, tags=["Inventory"])
def recommend_batch(request: BatchForecastRequest):
    """
    Process multiple items.  Each item goes through the full MS1→MS2 pipeline.
    Uses MS2's server-streaming RPC to retrieve recommendations in a single call.
    """
    results = []

    # Step 1: Fetch forecasts from MS1 for each item
    forecasts = {}
    for item in request.items:
        try:
            with _ms1_channel() as ch:
                stub = pb2_grpc.DemandForecastServiceStub(ch)
                resp = stub.ForecastDemand(pb2.DemandForecastRequest(
                    item_id=item.item_id,
                    historical_demand=item.historical_demand,
                    forecast_horizon=item.forecast_horizon,
                    warehouse_id=item.warehouse_id,
                ), timeout=10)
                forecasts[item.item_id] = resp
        except grpc.RpcError as e:
            _grpc_error_to_http(e)

    # Step 2: Send batch to MS2 via server streaming
    batch_items = []
    for item in request.items:
        f = forecasts[item.item_id]
        batch_items.append(pb2.InventoryOptimizationRequest(
            item_id=item.item_id,
            current_stock=item.current_stock,
            predicted_demand=f.predicted_demand,
            reorder_level=item.reorder_level,
            safety_stock=item.safety_stock or 0,
            supplier_lead_time=item.supplier_lead_time or 0,
        ))

    try:
        with _ms2_channel() as ch:
            stub = pb2_grpc.InventoryOptimizationServiceStub(ch)
            for ms2_resp in stub.StreamInventoryRecommendations(
                    pb2.BatchOptimizationRequest(items=batch_items), timeout=30):
                f = forecasts[ms2_resp.item_id]
                action_name = "SCALE_UP" if ms2_resp.inventory_adjustment_action == pb2.InventoryAdjustmentAction.SCALE_UP else "SCALE_DOWN"
                results.append(ForecastResponse(
                    item_id=ms2_resp.item_id,
                    predicted_demand=f.predicted_demand,
                    forecast_confidence=f.forecast_confidence,
                    forecast_horizon=f.forecast_horizon,
                    reorder_quantity=ms2_resp.reorder_quantity,
                    inventory_adjustment_action=action_name,
                    explanation_message=ms2_resp.explanation_message,
                ))
    except grpc.RpcError as e:
        _grpc_error_to_http(e)

    return BatchForecastResponse(recommendations=results)
