package com.iscf.forecast;

import com.iscf.forecast.proto.InventoryProto.*;
import com.iscf.forecast.proto.DemandForecastServiceGrpc;

import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.Status;
import io.grpc.stub.StreamObserver;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class DemandForecastServer {

    private static final Logger log = Logger.getLogger(DemandForecastServer.class.getName());
    private static final int PORT = Integer.parseInt(System.getenv().getOrDefault("GRPC_PORT", "50051"));

    public static void main(String[] args) throws IOException, InterruptedException {
        Server server = ServerBuilder.forPort(PORT)
                .addService(new DemandForecastServiceImpl())
                .build()
                .start();

        log.info("MS1 Demand Forecast listening on port " + PORT);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            log.info("Shutting down gRPC server...");
            server.shutdown();
        }));

        server.awaitTermination();
    }

    // ───────────────────────────────────────────────────────────────────────
    //  Service Implementation
    // ───────────────────────────────────────────────────────────────────────
    static class DemandForecastServiceImpl extends DemandForecastServiceGrpc.DemandForecastServiceImplBase {

        /**
         * Unary RPC – single forecast request.
         */
        @Override
        public void forecastDemand(DemandForecastRequest request,
                                   StreamObserver<DemandForecastResponse> responseObserver) {
            log.info("forecastDemand → item=" + request.getItemId()
                    + "  samples=" + request.getHistoricalDemandCount());

            if (request.getItemId().isEmpty()) {
                responseObserver.onError(Status.INVALID_ARGUMENT
                        .withDescription("item_id must not be empty").asRuntimeException());
                return;
            }
            if (request.getHistoricalDemandCount() == 0) {
                responseObserver.onError(Status.INVALID_ARGUMENT
                        .withDescription("historical_demand must contain at least one value").asRuntimeException());
                return;
            }

            DemandForecastResponse resp = buildForecast(
                    request.getItemId(),
                    request.getHistoricalDemandList(),
                    request.getForecastHorizon());

            responseObserver.onNext(resp);
            responseObserver.onCompleted();
        }

        /**
         * Client-Streaming RPC – CLIENT STREAMING FEATURE.
         *
         * Why client streaming?
         * Demand observations arrive continuously from IoT sensors and POS
         * terminals distributed across the warehouse.  Rather than accumulating
         * all readings client-side before sending a single large request, each
         * reading is streamed as it arrives.  The server aggregates them into a
         * running sum and count, then returns one consolidated forecast when the
         * stream closes – reducing client-side memory pressure and enabling
         * real-time data ingestion from resource-constrained edge devices.
         */
        @Override
        public StreamObserver<DemandForecastRequest> streamDemandObservations(
                StreamObserver<DemandForecastResponse> responseObserver) {

            return new StreamObserver<>() {
                private final List<Float> allDemand = new ArrayList<>();
                private String itemId = "";
                private String warehouseId = "";
                private int forecastHorizon = 1;

                @Override
                public void onNext(DemandForecastRequest req) {
                    if (itemId.isEmpty()) {
                        itemId       = req.getItemId();
                        warehouseId  = req.getWarehouseId();
                        forecastHorizon = req.getForecastHorizon();
                    }
                    allDemand.addAll(req.getHistoricalDemandList());
                    log.info("  streamDemandObservations: received chunk for " + itemId
                            + " (" + req.getHistoricalDemandCount() + " values)");
                }

                @Override
                public void onError(Throwable t) {
                    log.warning("Stream error: " + t.getMessage());
                }

                @Override
                public void onCompleted() {
                    if (allDemand.isEmpty()) {
                        responseObserver.onError(Status.INVALID_ARGUMENT
                                .withDescription("No demand observations received").asRuntimeException());
                        return;
                    }
                    DemandForecastResponse resp = buildForecast(itemId, allDemand, forecastHorizon);
                    log.info("  streamDemandObservations: sending forecast for " + itemId
                            + " predicted=" + resp.getPredictedDemand());
                    responseObserver.onNext(resp);
                    responseObserver.onCompleted();
                }
            };
        }

        // ── Algorithm ─────────────────────────────────────────────────────
        private DemandForecastResponse buildForecast(String itemId,
                                                     List<Float> history,
                                                     int horizon) {
            int windowSize = Math.min(history.size(), Math.max(horizon, 3));
            List<Float> window = history.subList(history.size() - windowSize, history.size());

            // Moving average
            float movingAvg = (float) window.stream()
                    .mapToDouble(Float::doubleValue).average().orElse(0);

            // Confidence: inverse of coefficient of variation (capped 0-1)
            float mean = movingAvg;
            float variance = 0;
            for (float v : window) variance += (v - mean) * (v - mean);
            variance /= window.size();
            float stdDev   = (float) Math.sqrt(variance);
            float confidence = mean > 0 ? Math.max(0f, Math.min(1f, 1f - stdDev / mean)) : 0.5f;

            return DemandForecastResponse.newBuilder()
                    .setItemId(itemId)
                    .setPredictedDemand(movingAvg)
                    .setForecastConfidence(confidence)
                    .setForecastHorizon(horizon)
                    .build();
        }
    }
}
