"""
MS2 – Inventory Optimization gRPC Server (Python)
Run: python server.py
"""

import grpc
import logging
from concurrent import futures

import inventory_pb2 as pb2
import inventory_pb2_grpc as pb2_grpc

logging.basicConfig(level=logging.INFO, format="%(asctime)s [MS2] %(message)s")
log = logging.getLogger(__name__)

GRPC_PORT = "[::]:50052"


class InventoryOptimizationServicer(pb2_grpc.InventoryOptimizationServiceServicer):

    # ------------------------------------------------------------------ #
    #  Unary RPC
    # ------------------------------------------------------------------ #
    def OptimizeInventory(self, request, context):
        log.info("OptimizeInventory → item=%s stock=%d demand=%.1f reorder=%d",
                 request.item_id, request.current_stock,
                 request.predicted_demand, request.reorder_level)

        # --- Validation ---
        if not request.item_id:
            context.abort(grpc.StatusCode.INVALID_ARGUMENT, "item_id must not be empty")

        if request.current_stock < 0:
            context.abort(grpc.StatusCode.INVALID_ARGUMENT,
                          f"current_stock cannot be negative (got {request.current_stock})")

        if request.predicted_demand < 0:
            context.abort(grpc.StatusCode.INVALID_ARGUMENT,
                          "predicted_demand cannot be negative")

        if request.reorder_level < 0:
            context.abort(grpc.StatusCode.INVALID_ARGUMENT,
                          "reorder_level cannot be negative")

        return self._compute_recommendation(request)

    # ------------------------------------------------------------------ #
    #  Server-Streaming RPC  (FREE-CHOICE feature – server streaming)
    # ------------------------------------------------------------------ #
    def StreamInventoryRecommendations(self, request, context):
        """
        Client sends a batch of items; server streams back one recommendation
        per item as soon as each is computed.

        Why server streaming here?
        A warehouse dashboard may need to refresh recommendations for dozens of
        SKUs simultaneously.  Server streaming lets the UI render each result as
        it arrives rather than waiting for the full batch, giving the operator
        near-real-time feedback without multiple round-trips.
        """
        log.info("StreamInventoryRecommendations → %d items", len(request.items))
        for item_req in request.items:
            if not context.is_active():
                break

            # Skip invalid items gracefully in streaming context
            if item_req.current_stock < 0 or item_req.predicted_demand < 0:
                log.warning("Skipping invalid item %s", item_req.item_id)
                continue

            yield self._compute_recommendation(item_req)

    # ------------------------------------------------------------------ #
    #  Core business logic
    # ------------------------------------------------------------------ #
    @staticmethod
    def _compute_recommendation(req) -> pb2.InventoryOptimizationResponse:
        safety   = req.safety_stock or 0
        lead     = req.supplier_lead_time or 0

        # Effective demand threshold accounts for safety stock and lead time
        effective_threshold = req.predicted_demand + req.reorder_level + safety

        if req.current_stock < effective_threshold:
            # How many units to bring stock up to a comfortable level
            reorder_qty = int(effective_threshold - req.current_stock + req.predicted_demand * lead)
            action = pb2.InventoryAdjustmentAction.SCALE_UP
            msg = (
                f"Stock ({req.current_stock}) is below the threshold "
                f"({effective_threshold:.0f}). Recommend ordering {reorder_qty} units."
            )
        else:
            reorder_qty = 0
            action = pb2.InventoryAdjustmentAction.SCALE_DOWN
            msg = (
                f"Stock ({req.current_stock}) is sufficient against "
                f"demand ({req.predicted_demand:.1f}) + reorder level ({req.reorder_level}). "
                f"No immediate action required."
            )

        return pb2.InventoryOptimizationResponse(
            item_id=req.item_id,
            reorder_quantity=reorder_qty,
            inventory_adjustment_action=action,
            explanation_message=msg,
        )


def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    pb2_grpc.add_InventoryOptimizationServiceServicer_to_server(
        InventoryOptimizationServicer(), server
    )
    server.add_insecure_port(GRPC_PORT)
    server.start()
    log.info("MS2 Inventory Optimization listening on %s", GRPC_PORT)
    server.wait_for_termination()


if __name__ == "__main__":
    serve()
