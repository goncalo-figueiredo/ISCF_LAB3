"""
MS2 – Test Client  (run against the local or containerised server)
Usage: python client.py [host] [port]
"""

import sys
import grpc
import inventory_pb2 as pb2
import inventory_pb2_grpc as pb2_grpc

HOST = sys.argv[1] if len(sys.argv) > 1 else "localhost"
PORT = sys.argv[2] if len(sys.argv) > 2 else "50052"


def run():
    with grpc.insecure_channel(f"{HOST}:{PORT}") as channel:
        stub = pb2_grpc.InventoryOptimizationServiceStub(channel)

        print("\n=== Test 1: Low stock → SCALE_UP ===")
        resp = stub.OptimizeInventory(pb2.InventoryOptimizationRequest(
            item_id="ITEM-001",
            current_stock=10,
            predicted_demand=50.0,
            reorder_level=20,
            safety_stock=5,
            supplier_lead_time=3,
        ))
        _print(resp)

        print("\n=== Test 2: High stock → SCALE_DOWN ===")
        resp = stub.OptimizeInventory(pb2.InventoryOptimizationRequest(
            item_id="ITEM-002",
            current_stock=200,
            predicted_demand=30.0,
            reorder_level=10,
        ))
        _print(resp)

        print("\n=== Test 3: Server-Streaming batch ===")
        batch = pb2.BatchOptimizationRequest(items=[
            pb2.InventoryOptimizationRequest(
                item_id=f"ITEM-{i:03d}",
                current_stock=i * 5,
                predicted_demand=25.0,
                reorder_level=15,
            )
            for i in range(1, 6)
        ])
        for rec in stub.StreamInventoryRecommendations(batch):
            _print(rec)

        print("\n=== Test 4: Validation error – negative stock ===")
        try:
            stub.OptimizeInventory(pb2.InventoryOptimizationRequest(
                item_id="BAD-ITEM",
                current_stock=-5,
                predicted_demand=10.0,
                reorder_level=5,
            ))
        except grpc.RpcError as e:
            print(f"  ✓ Got expected error: [{e.code()}] {e.details()}")


def _print(r):
    action = "SCALE_UP" if r.inventory_adjustment_action == pb2.InventoryAdjustmentAction.SCALE_UP else "SCALE_DOWN"
    print(f"  item={r.item_id}  action={action}  qty={r.reorder_quantity}")
    print(f"  → {r.explanation_message}")


if __name__ == "__main__":
    run()
