# ISCF Lab 3 – Microservices Architecture with gRPC

**Deadline:** 30th May 2026 · FCT Nova

## Architecture

```
Web App (port 3000)
    │  HTTP
    ▼
REST API / FastAPI (port 8000)
    │         │
    │ gRPC    │ gRPC
    ▼         ▼
  MS1 Java  MS2 Python
 (port 50051) (port 50052)
```

## Quick Start (Docker Compose)

```bash
docker compose up --build
```

Then open **http://localhost:3000** in your browser.

| Service   | URL / Port           |
|-----------|----------------------|
| Web UI    | http://localhost:3000 |
| REST API  | http://localhost:8000 |
| API Docs  | http://localhost:8000/docs |
| MS1 gRPC  | localhost:50051      |
| MS2 gRPC  | localhost:50052      |

---

## Project Structure

```
iscf-lab3/
├── protobuf/
│   └── inventory.proto          # Shared Protobuf contract
│
├── ms1-java/                    # MS1 – Demand Forecast (Java)
│   ├── src/main/
│   │   ├── proto/inventory.proto
│   │   └── java/com/iscf/forecast/
│   │       └── DemandForecastServer.java
│   ├── pom.xml
│   └── Dockerfile
│
├── ms2-python/                  # MS2 – Inventory Optimisation (Python)
│   ├── server.py
│   ├── client.py                # Test client
│   ├── requirements.txt
│   └── Dockerfile
│
├── rest-api/                    # Orchestrating REST API (FastAPI)
│   ├── main.py
│   ├── requirements.txt
│   └── Dockerfile
│
├── web-app/                     # Frontend (HTML/JS + nginx)
│   ├── index.html
│   ├── nginx.conf
│   └── Dockerfile
│
└── docker-compose.yml
```

---

## Development (without Docker)

### Generate Python stubs

```bash
cd ms2-python
pip install grpcio-tools==1.54.2
python -m grpc_tools.protoc -I../protobuf \
    --python_out=. --grpc_python_out=. \
    ../protobuf/inventory.proto
```

### Run MS2 server locally

```bash
cd ms2-python
python server.py
```

### Run MS2 test client

```bash
cd ms2-python
python client.py          # against localhost:50052
```

### Build and run MS1 (Java)

```bash
cd ms1-java
mvn package
java -jar target/ms1-demand-forecast-1.0-SNAPSHOT.jar
```

### Run REST API locally

```bash
cd rest-api
# copy generated stubs from ms2-python first
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

---

## gRPC Streaming Feature

This project implements **Client Streaming** in MS1 (`StreamDemandObservations`):

- The client sends demand observations **one chunk at a time** (simulating IoT sensor feeds)
- The server accumulates them and returns a single forecast when the stream closes

**Justification:** In a smart distribution center, demand data arrives continuously from POS terminals and warehouse sensors. Client streaming lets each edge device push readings as they occur, without buffering the full history before making a gRPC call — reducing memory usage on constrained devices and enabling real-time ingestion.

The project also demonstrates **Server Streaming** in MS2 (`StreamInventoryRecommendations`):

- The client sends a batch of items in one message
- The server yields one recommendation per item as each is computed, so the dashboard can render results progressively

---

## Evaluation Checklist

| Criterion                          | Points |
|------------------------------------|--------|
| MS1 correct implementation         | 6      |
| MS2 correct implementation         | 6      |
| REST API orchestration             | 4      |
| Web page / app                     | 2      |
| gRPC streaming (+ oral justif.)    | 2      |
| **Total**                          | **20** |
